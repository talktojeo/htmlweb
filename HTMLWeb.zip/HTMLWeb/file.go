pipeline {
	agent any
	 environment {
	   registry = "josephjeethu/nodeapp"
	   registryCredential = 'dockerhub_ceredentials'
	   dockerImage = ''
	   ECRURL = 'https://268016723435.dkr.ecr.us-east-2.amazonaws.com/mindlogics'
       ECRCRED = 'ecr:us-east-2:awscredentials'
	   VERSION = "${BUILD_NUMBER}"
	   ECRREPONAME = 'nodeapplication'  //ECR Repo name and Project Application name should be same else will conflict
	   IMAGE = "$ECRREPONAME:$VERSION"  
	
	 }
	 stages {
	   stage('Get SCM GITHUB') {
		 steps {
		 git credentialsId: 'github_credentials', url: 'https://github.com/josephjeethu/Nodejs-application-with-docker.git'
		  }
	   }
	   stage('BUILD image') {
		 steps{
		   script {
			 dockerImage = docker.build registry + ":$BUILD_NUMBER" // build image with DOCKER TAG for Docker Repo Upload
			 docker.build('$IMAGE')        //build image for ECR for Amazon ECR Upload
		   }
		 }
	   }

	   stage('Run Docker container on Jenkins Agent') {
             
		steps 
		{
			sh "docker rm -f nodeapp1"
			sh "docker run -d -p 9005:9005 --name nodeapp1 $registry:$BUILD_NUMBER"

		}
     	}
		stage('PUSH image - DOCKERHUB') {
			steps{
			  script {
				docker.withRegistry( '', registryCredential ) {
				  dockerImage.push()
				}
			  }
			}
		}
			stage('PUSH image - ECR') {
             	steps 
				{ 				
					script
               		 {
                    docker.withRegistry(ECRURL, ECRCRED)
                    {
                       docker.image(IMAGE).push() // THIS COMMAND WILL TAG IMAGE FOR ECR AND PUSH
                    }
                	}
				}
			}
			stage('PUSH image - GITHUB') {
             
				steps 
				{
					sh "docker login https://docker.pkg.github.com -u josephjeethu -p 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"
					// EXPLICITLY TAGGING FOR GIT HUB ONLY THEN IT WILL ACCEPT
					sh "docker tag $registry:$BUILD_NUMBER docker.pkg.github.com/josephjeethu/nodedocker/nodeapp:v$BUILD_NUMBER"
					sh "docker push docker.pkg.github.com/josephjeethu/nodedocker/nodeapp:v$BUILD_NUMBER"
		
				}
				}
	  
	 }
   }