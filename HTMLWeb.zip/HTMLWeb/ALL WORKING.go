
pipeline {
	agent any
	environment 
	 {
		 VERSION = "${BUILD_NUMBER}"
		 PROJECT = 'nodeapplication'
		 IMAGE = "$PROJECT:$VERSION"
		 ECRURL = 'https://268016723435.dkr.ecr.us-east-2.amazonaws.com/nodeapplication'
		 ECRCRED = 'ecr:us-east-2:awscredentials'
	 }   
	 stages {
	   stage('GetSCM') {
 
		  steps {
 
			 // Get some code from a GitHub repository
 
			 git 'https://github.com/josephjeethu/Nodejs-application-with-docker.git'
		  }
		  }
		  stage('Image Build'){
			  steps{
				  script{
						docker.build('$IMAGE')
				  }
			  }
		  }
		  stage('Push Image'){
		  steps{
			  script
				 {
					 docker.withRegistry(ECRURL, ECRCRED)
					 {
						 docker.image(IMAGE).push()
					 }
				 }
			 }
		  }
	 }
	
 }